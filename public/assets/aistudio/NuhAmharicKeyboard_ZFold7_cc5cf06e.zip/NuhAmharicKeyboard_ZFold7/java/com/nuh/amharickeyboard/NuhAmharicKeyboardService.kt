package com.nuh.amharickeyboard

import android.content.Context
import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout

class NuhAmharicKeyboardService : InputMethodService() {

    private var isSplitMode = false
    private var isAmharic = true
    private var isShifted = false

    // የመጨረሻውን ተነባቢ ፊደል ለመያዝ (ለ Fyn Geez 2 ፎነቲክስ)
    private var lastConsonant: Char? = null
    private var lastWasKaibU = false // ለዲቃላ ፊደላት (ለምሳሌ q + u + a = ቋ)

    private var vowelBar: LinearLayout? = null
    private var currentView: View? = null

    override fun onCreateInputView(): View {
        checkFoldableState()
        val layoutId = if (isSplitMode) {
            R.layout.keyboard_split_view
        } else {
            R.layout.keyboard_standard_view
        }
        val view = layoutInflater.inflate(layoutId, null)
        currentView = view
        vowelBar = view.findViewById(R.id.vowel_bar)
        bindAllKeys(view)
        updateKeyLabels(view)
        return view
    }

    /**
     * የ Galaxy Z Fold 7 ስክሪን መከፈቱን (Inner Screen > 600dp) ወይም መታጠፉን (Cover Screen) ያረጋግጣል
     */
    private fun checkFoldableState() {
        val screenWidthDp = resources.configuration.screenWidthDp
        isSplitMode = screenWidthDp >= 600
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val wasSplit = isSplitMode
        checkFoldableState()
        if (wasSplit != isSplitMode) {
            lastConsonant = null
            lastWasKaibU = false
            setInputView(onCreateInputView())
        }
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        lastConsonant = null
        lastWasKaibU = false
        clearVowelBar()
    }

    private fun bindAllKeys(view: View) {
        val letterKeyIds = mapOf(
            R.id.key_q to 'q', R.id.key_w to 'w', R.id.key_e to 'e', R.id.key_r to 'r', R.id.key_t to 't',
            R.id.key_y to 'y', R.id.key_u to 'u', R.id.key_i to 'i', R.id.key_o to 'o', R.id.key_p to 'p',
            R.id.key_a to 'a', R.id.key_s to 's', R.id.key_d to 'd', R.id.key_f to 'f', R.id.key_g to 'g',
            R.id.key_h to 'h', R.id.key_j to 'j', R.id.key_k to 'k', R.id.key_l to 'l',
            R.id.key_z to 'z', R.id.key_x to 'x', R.id.key_c to 'c', R.id.key_v to 'v', R.id.key_b to 'b',
            R.id.key_n to 'n', R.id.key_m to 'm'
        )

        for ((id, baseChar) in letterKeyIds) {
            view.findViewById<Button>(id)?.setOnClickListener {
                vibrateKey()
                val actualChar = if (isShifted) baseChar.uppercaseChar() else baseChar
                handleCharacterInput(actualChar)
                if (isShifted) {
                    isShifted = false
                    updateKeyLabels(view)
                }
            }
        }

        // Shift ቁልፎች (በግራ እና በቀኝ)
        val shiftListener = View.OnClickListener {
            vibrateKey()
            isShifted = !isShifted
            updateKeyLabels(view)
        }
        view.findViewById<Button>(R.id.key_shift_left)?.setOnClickListener(shiftListener)
        view.findViewById<Button>(R.id.key_shift_right)?.setOnClickListener(shiftListener)

        // Space ቁልፎች (በግራ እና በቀኝ)
        val spaceListener = View.OnClickListener {
            vibrateKey()
            lastConsonant = null
            lastWasKaibU = false
            clearVowelBar()
            currentInputConnection?.commitText(" ", 1)
        }
        view.findViewById<Button>(R.id.key_space_left)?.setOnClickListener(spaceListener)
        view.findViewById<Button>(R.id.key_space_right)?.setOnClickListener(spaceListener)

        // Backspace ቁልፍ
        view.findViewById<Button>(R.id.key_backspace)?.setOnClickListener {
            vibrateKey()
            lastConsonant = null
            lastWasKaibU = false
            clearVowelBar()
            currentInputConnection?.deleteSurroundingText(1, 0)
        }

        // Enter ቁልፍ
        view.findViewById<Button>(R.id.key_enter)?.setOnClickListener {
            vibrateKey()
            lastConsonant = null
            lastWasKaibU = false
            clearVowelBar()
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }

        // የቋንቋ መቀየሪያ (አማርኛ <-> English)
        view.findViewById<Button>(R.id.key_lang)?.setOnClickListener {
            vibrateKey()
            isAmharic = !isAmharic
            lastConsonant = null
            lastWasKaibU = false
            clearVowelBar()
            updateKeyLabels(view)
        }

        // ስርዓተ ነጥብ (። / ፣)
        view.findViewById<Button>(R.id.key_punct)?.setOnClickListener {
            vibrateKey()
            lastConsonant = null
            lastWasKaibU = false
            val punct = if (isAmharic) "። " else ". "
            currentInputConnection?.commitText(punct, 1)
        }
    }

    /**
     * የ Fyn Geez 2 ፎነቲክስ አጻጻፍ አመክንዮ (Core Phonetic Logic)
     */
    private fun handleCharacterInput(ch: Char) {
        val ic = currentInputConnection ?: return

        if (!isAmharic) {
            ic.commitText(ch.toString(), 1)
            return
        }

        // 1. ዲቃላ ፊደል ማጣራት (ለምሳሌ q + u + a -> ቋ)
        if (lastConsonant != null && lastWasKaibU && (ch == 'a' || ch == 'A')) {
            val labio = FynGeezEngine.getLabiovelar(lastConsonant!!)
            if (labio != null) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(labio, 1)
                lastConsonant = null
                lastWasKaibU = false
                return
            }
        }

        // 2. አናባቢ ፊደል ሲጫን (e, u, i, a, E, o)
        val isVowel = ch in listOf('e', 'u', 'i', 'a', 'E', 'o', 'I')
        if (isVowel) {
            if (lastConsonant != null) {
                val combined = FynGeezEngine.combineConsonantAndVowel(lastConsonant!!, ch)
                if (combined != null) {
                    ic.deleteSurroundingText(1, 0) // የቀድሞውን ሳድስ ፊደል አጥፍቶ በአዲሱ ቤት ይተካል
                    ic.commitText(combined, 1)
                    if (ch == 'u') {
                        lastWasKaibU = true
                    } else {
                        lastConsonant = null
                        lastWasKaibU = false
                    }
                    return
                }
            }
            // ብቻውን የሚጻፍ አናባቢ (አ፣ ኡ፣ ኢ፣ ኤ፣ እ፣ ኦ)
            val standalone = FynGeezEngine.standaloneVowels[ch] ?: ch.toString()
            ic.commitText(standalone, 1)
            lastConsonant = null
            lastWasKaibU = false
            clearVowelBar()
            return
        }

        // 3. ተነባቢ ፊደል ሲጫን (መነሻውን በ6ኛ ቤት / ሳድስ ያስቀምጣል)
        val sadis = FynGeezEngine.getBaseSadis(ch)
        if (sadis != null) {
            ic.commitText(sadis, 1)
            lastConsonant = ch
            lastWasKaibU = false
            populateVowelBar(ch)
        } else {
            ic.commitText(ch.toString(), 1)
            lastConsonant = null
            lastWasKaibU = false
            clearVowelBar()
        }
    }

    /**
     * ከላይ ባለው Ribbon Bar የፊደሉን 7 ቤቶች ይዘረዝራል (በቀጥታ በመንካት ለመምረጥ)
     */
    private fun populateVowelBar(consonant: Char) {
        val bar = vowelBar ?: return
        bar.removeAllViews()
        val family = FynGeezEngine.getFamily(consonant)
        for (charStr in family) {
            val btn = Button(this).apply {
                text = charStr
                textSize = 18f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundResource(R.drawable.key_background)
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
                ).apply {
                    setMargins(4, 2, 4, 2)
                }
                layoutParams = params
                setOnClickListener {
                    vibrateKey()
                    currentInputConnection?.deleteSurroundingText(1, 0)
                    currentInputConnection?.commitText(charStr, 1)
                    lastConsonant = null
                    lastWasKaibU = false
                    clearVowelBar()
                }
            }
            bar.addView(btn)
        }
    }

    private fun clearVowelBar() {
        vowelBar?.removeAllViews()
    }

    private fun updateKeyLabels(view: View) {
        val labelMap = mapOf(
            R.id.key_q to ("ቅ" to "ቐ"), R.id.key_w to ("ው" to "ፅ"), R.id.key_e to ("እ" to "ኧ"),
            R.id.key_r to ("ር" to "ር"), R.id.key_t to ("ት" to "ጥ"), R.id.key_y to ("ይ" to "ይ"),
            R.id.key_u to ("ኡ" to "ኡ"), R.id.key_i to ("ኢ" to "ኧ"), R.id.key_o to ("ኦ" to "ኦ"),
            R.id.key_p to ("ፕ" to "ጵ"), R.id.key_a to ("አ" to "ዕ"), R.id.key_s to ("ስ" to "ሥ"),
            R.id.key_d to ("ድ" to "ዽ"), R.id.key_f to ("ፍ" to "ፍ"), R.id.key_g to ("ግ" to "ጝ"),
            R.id.key_h to ("ህ" to "ሕ"), R.id.key_j to ("ጅ" to "ጅ"), R.id.key_k to ("ክ" to "ኽ"),
            R.id.key_l to ("ል" to "ል"), R.id.key_z to ("ዝ" to "ዥ"), R.id.key_x to ("ሽ" to "ጽ"),
            R.id.key_c to ("ች" to "ጭ"), R.id.key_v to ("ቭ" to "ቭ"), R.id.key_b to ("ብ" to "ኅ"),
            R.id.key_n to ("ን" to "ኝ"), R.id.key_m to ("ም" to "ም")
        )

        val enKeys = mapOf(
            R.id.key_q to "q", R.id.key_w to "w", R.id.key_e to "e", R.id.key_r to "r", R.id.key_t to "t",
            R.id.key_y to "y", R.id.key_u to "u", R.id.key_i to "i", R.id.key_o to "o", R.id.key_p to "p",
            R.id.key_a to "a", R.id.key_s to "s", R.id.key_d to "d", R.id.key_f to "f", R.id.key_g to "g",
            R.id.key_h to "h", R.id.key_j to "j", R.id.key_k to "k", R.id.key_l to "l",
            R.id.key_z to "z", R.id.key_x to "x", R.id.key_c to "c", R.id.key_v to "v", R.id.key_b to "b",
            R.id.key_n to "n", R.id.key_m to "m"
        )

        for ((id, enChar) in enKeys) {
            val btn = view.findViewById<Button>(id) ?: continue
            if (isAmharic) {
                val pair = labelMap[id]
                val amChar = if (isShifted) pair?.second else pair?.first
                val subEn = if (isShifted) enChar.uppercase() else enChar
                btn.text = if (isSplitMode) "$amChar
$subEn" else "$amChar"
            } else {
                btn.text = if (isShifted) enChar.uppercase() else enChar
            }
        }
    }

    private fun vibrateKey() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val mgr = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            mgr.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}
