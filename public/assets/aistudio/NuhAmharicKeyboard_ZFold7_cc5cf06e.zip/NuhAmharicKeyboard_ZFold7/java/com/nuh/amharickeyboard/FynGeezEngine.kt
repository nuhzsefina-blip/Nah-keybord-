package com.nuh.amharickeyboard

/**
 * Fyn Geez 2 (ፋይን ግዕዝ 2) ፎነቲክስ አቀናባሪ
 * በግዕዝ (6ኛ ቤት) ጀምሮ በአናባቢዎች (e, u, i, a, E, o) ወደ ሌሎች ቤቶች ይቀይራል።
 */
object FynGeezEngine {

    // የእያንዳንዱ ፊደል 7 ቤቶች: [ግዕዝ(1), ካዕብ(2), ሣልስ(3), ራብዕ(4), ኃምስ(5), ሳድስ(6-መነሻ), ሳብዕ(7)]
    private val baseMap: Map<Char, List<String>> = mapOf(
        'h' to listOf("ሀ", "ሁ", "ሂ", "ሃ", "ሄ", "ህ", "ሆ"),
        'H' to listOf("ሐ", "ሑ", "ሒ", "ሓ", "ሔ", "ሕ", "ሖ"),
        'l' to listOf("ለ", "ሉ", "ሊ", "ላ", "ሌ", "ል", "ሎ"),
        'm' to listOf("መ", "ሙ", "ሚ", "ማ", "ሜ", "ም", "ሞ"),
        's' to listOf("ሰ", "ሱ", "ሲ", "ሳ", "ሴ", "ስ", "ሶ"),
        'S' to listOf("ሠ", "ሡ", "ሢ", "ሣ", "ሤ", "ሥ", "ሦ"),
        'r' to listOf("ረ", "ሩ", "ሪ", "ራ", "ሬ", "ር", "ሮ"),
        'x' to listOf("ሸ", "ሹ", "ሺ", "ሻ", "ሼ", "ሽ", "ሾ"),
        'q' to listOf("ቀ", "ቁ", "ቂ", "ቃ", "ቄ", "ቅ", "ቆ"),
        'Q' to listOf("ቐ", "ቑ", "ቒ", "ቓ", "ቔ", "ቕ", "ቖ"),
        'b' to listOf("በ", "ቡ", "ቢ", "ባ", "ቤ", "ብ", "ቦ"),
        'v' to listOf("ቨ", "ቩ", "ቪ", "ቫ", "ቬ", "ቭ", "ቮ"),
        't' to listOf("ተ", "ቱ", "ቲ", "ታ", "ቴ", "ት", "ቶ"),
        'T' to listOf("ጠ", "ጡ", "ጢ", "ጣ", "ጤ", "ጥ", "ጦ"),
        'c' to listOf("ቸ", "ቹ", "ቺ", "ቻ", "ቼ", "ች", "ቾ"),
        'C' to listOf("ጨ", "ጩ", "ጪ", "ጫ", "ጬ", "ጭ", "ጮ"),
        'n' to listOf("ነ", "ኑ", "ኒ", "ና", "ኔ", "ን", "ኖ"),
        'N' to listOf("ኘ", "ኙ", "ኚ", "ኛ", "ኜ", "ኝ", "ኞ"),
        'k' to listOf("ከ", "ኩ", "ኪ", "ካ", "ኬ", "ክ", "ኮ"),
        'K' to listOf("ኸ", "ኹ", "ኺ", "ኻ", "ኼ", "ኽ", "ኾ"),
        'w' to listOf("ወ", "ዉ", "ዊ", "ዋ", "ዌ", "ው", "ዎ"),
        'z' to listOf("ዘ", "ዙ", "ዚ", "ዛ", "ዜ", "ዝ", "ዞ"),
        'Z' to listOf("ዠ", "ዡ", "ዢ", "ዣ", "ዤ", "ዥ", "ዦ"),
        'y' to listOf("የ", "ዩ", "ዪ", "ያ", "ዬ", "ይ", "ዮ"),
        'd' to listOf("ደ", "ዱ", "ዲ", "ዳ", "ዴ", "ድ", "ዶ"),
        'D' to listOf("ዸ", "ዹ", "ዺ", "ዻ", "ዼ", "ዽ", "ዾ"),
        'j' to listOf("ጀ", "ጁ", "ጂ", "ጃ", "ጄ", "ጅ", "ጆ"),
        'g' to listOf("ገ", "ጉ", "ጊ", "ጋ", "ጌ", "ግ", "ጎ"),
        'G' to listOf("ጘ", "ጙ", "ጚ", "ጛ", "ጜ", "ጝ", "ጞ"),
        'p' to listOf("ፐ", "ፑ", "ፒ", "ፓ", "ፔ", "ፕ", "ፖ"),
        'P' to listOf("ጰ", "ጱ", "ጲ", "ጳ", "ጴ", "ጵ", "ጶ"),
        'f' to listOf("ፈ", "ፉ", "ፊ", "ፋ", "ፌ", "ፍ", "ፎ"),
        // ድርብ ቁልፎች (Shift ሲጫን የሚመጡ ልዩ ፊደላት)
        'X' to listOf("ጸ", "ጹ", "ጺ", "ጻ", "ጼ", "ጽ", "ጾ"),
        'W' to listOf("ፀ", "ፁ", "ፂ", "ፃ", "ፄ", "ፅ", "ፆ"),
        'A' to listOf("ዐ", "ዑ", "ዒ", "ዓ", "ዔ", "ዕ", "ዖ"),
        'B' to listOf("ኀ", "ኁ", "ኂ", "ኃ", "ኄ", "ኅ", "ኆ")
    )

    // የአናባቢ ፊደላት (አ፣ ኡ፣ ኢ፣ ኣ፣ ኤ፣ እ፣ ኦ)
    val standaloneVowels: Map<Char, String> = mapOf(
        'e' to "እ",
        'u' to "ኡ",
        'i' to "ኢ",
        'a' to "አ",
        'E' to "ኤ",
        'o' to "ኦ",
        'I' to "ኧ"
    )

    // የአናባቢ ኢንዴክስ (0=ግዕዝ, 1=ካዕብ, 2=ሣልስ, 3=ራብዕ, 4=ኃምስ, 5=ሳድስ, 6=ሳብዕ)
    private val vowelIndexMap: Map<Char, Int> = mapOf(
        'e' to 0, // ኧ / ግዕዝ (ለምሳሌ s + e -> ሰ)
        'u' to 1, // ኡ / ካዕብ (s + u -> ሱ)
        'i' to 2, // ኢ / ሣልስ (s + i -> ሲ)
        'a' to 3, // ኣ / ራብዕ (s + a -> ሳ)
        'E' to 4, // ኤ / ኃምስ (s + E -> ሴ)
        'o' to 6  // ኦ / ሳብዕ (s + o -> ሶ)
    )

    // ዲቃላ ፊደላት (Labiovelars: ቋ፣ ጓ፣ ኳ፣ ኋ፣ ሟ፣ ሯ፣ ሷ፣ ቧ፣ ቷ፣ ኗ፣ ዟ፣ ዷ፣ ጧ፣ ጿ፣ ፏ)
    private val labiovelarMap: Map<Char, String> = mapOf(
        'q' to "ቋ", 'Q' to "ቛ", 'g' to "ጓ", 'k' to "ኳ", 'K' to "ዃ",
        'h' to "ኋ", 'B' to "ኋ", 'm' to "ሟ", 'r' to "ሯ", 's' to "ሷ",
        'x' to "ሿ", 'b' to "ቧ", 't' to "ቷ", 'c' to "ቿ", 'n' to "ኗ",
        'N' to "ኟ", 'z' to "ዟ", 'Z' to "ዧ", 'd' to "ዷ", 'j' to "ጇ",
        'T' to "ጧ", 'C' to "ጯ", 'P' to "ጷ", 'X' to "ጿ", 'f' to "ፏ"
    )

    /**
     * መነሻውን ሳድስ (6ኛ ቤት) ይመልሳል (ለምሳሌ 's' -> "ስ")
     */
    fun getBaseSadis(consonant: Char): String? {
        return baseMap[consonant]?.get(5)
    }

    /**
     * የፊደሉን 7 ቤቶች ዝርዝር ይመልሳል (ከላይ በ Ribbon Bar እንዲታይ)
     */
    fun getFamily(consonant: Char): List<String> {
        val list = baseMap[consonant]?.toMutableList() ?: return emptyList()
        labiovelarMap[consonant]?.let { list.add(it) }
        return list
    }

    /**
     * ከሳድስ ፊደል በኋላ አናባቢ ሲመጣ ወደ ተገቢው ቤት ይቀይራል
     */
    fun combineConsonantAndVowel(consonant: Char, vowel: Char): String? {
        val index = vowelIndexMap[vowel] ?: return null
        return baseMap[consonant]?.get(index)
    }

    /**
     * ዲቃላ ፊደል (ለምሳሌ q + u + a -> ቋ)
     */
    fun getLabiovelar(consonant: Char): String? {
        return labiovelarMap[consonant]
    }
}
